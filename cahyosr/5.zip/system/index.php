<?php
header("Location: https://wa.me/6285863972648");