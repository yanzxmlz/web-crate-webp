<?php
header("Location: https://github.cahyosr.my.id");